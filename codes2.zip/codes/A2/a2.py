import xml.etree.ElementTree as et
import threading
import time

class Sort:
	arr=[]
	start=0
	end=0
	def __init__(self,a):
		self.arr=a

	def partition(self,low,high):
		i=low
		j=high
		pivot=self.arr[low]
		while(i<j):
			while(self.arr[i]<=pivot and i<j):
				i=i+1
			while(self.arr[j]>pivot and i<=j):
				j=j-1
			
			if(i<=j):
				temp=self.arr[i]
				self.arr[i]=self.arr[j]
				self.arr[j]=temp
		temp=self.arr[low]
		self.arr[low]=self.arr[j]
		self.arr[j]=temp

		return j
		

	def quicksort(self,l,r):
		if(l<r):
			ind=self.partition(l,r)
			thread1=threading.Thread(target=self.quicksort,args=(1,ind-1))
			thread2=threading.Thread(target=self.quicksort,args=(ind+1,r))
			thread1.start()
			thread2.start()
			thread1.join()
			print thread1.getName()
			thread2.join()
			print thread2.getName()

	def display(self):
		print self.arr
		print "%S" % (self.end-self.start)
def readxml(filename):
	name=filename.split('.')
	if(name[1]=='xml'):
		tree=et.parse(filename)
		root=tree.getroot()
		a=map(int,root.text.split())
		obj=Sort(a)
		start=time.time()
		print "%S ####" % (start)
		obj.quicksort(0,len(a)-1)
		end=time.time()
		print "%S ****" % (end)
		obj.display()


def main():
	filename=raw_input("enter filename")
	readxml(filename)

main()
