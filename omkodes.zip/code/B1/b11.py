import json

def abc(b,r,c):
	for i in range(r):
		if(b[i][c]==1):
			return True
	i=r-1
	j=c-1
	while(i>=0 and j>=0):
		if(b[i][j]==1):
			return True
		i-=1	
		j-=1

	i=r-1
	j=c+1
	while(i>=0 and j<8):
		if(b[i][j]==1):
			return True
		i-=1	
		j+=1
	return False


def solve(b,r):
	i=0
	while(i<8):
		if(not abc(b,r,i)):
			b[r][i]=1
			if(r==7):
				return True
			else:
				if (solve(b,r+1)):
					return True
				else:
					b[r][i]=0
		i+=1
	if(i==8):
		return False


def printb(b):
	for i in range(8):
		for j in range(8):
			print(str(b[i][j])+" ",end='')
		print("\n")

with open("input.json") as f:
	data=json.load(f)

b=[[0 for x in range(8)] for x in range(8)]
if(data["start"]<0 or data["start"]>7):
	print("error")
else:
	b[0][data["start"]]=1
	if(solve(b,1)):
		print("success")
		printb(b)
