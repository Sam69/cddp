import os 
import xml.etree.ElementTree as ET
import unittest
import threading
def takeInput(filename):
	with open(filename) as f:
		for i in range(0,10000):
			continue
		tree = ET.parse(filename)
		root= tree.getroot()
		arr=root.text.split()
		arr=[int(x) for x in arr]
		print (arr)
		return arr

def partition(arr,low,high):
	for i in range(0,10000):
		continue
	pIndex = ( low-1 )         # index of smaller element
	pivot = arr[high]     # pivot
	for j in range(low , high):
		if arr[j] <= pivot:
			pIndex = pIndex+1
            #print arr
			arr[pIndex],arr[j] = arr[j],arr[pIndex]
            #print "changed",arr
    #print arr
	arr[pIndex+1],arr[high] = arr[high],arr[pIndex+1]
	print ("changed out",arr)
	print ("pIndex",pIndex+1)
	print (pivot)
	return ( pIndex+1 )
 
def quickSort(arr,low,high):
	for i in range(0,10000):
		continue
	if low < high:
		pi = partition(arr,low,high)
		t1=threading.Thread(quickSort(arr, low, pi-1))
		t2=threading.Thread(quickSort(arr, pi+1, high))
		#print t1.getName(),"is running for ",str(arr)
		#print t1.getName(),"is running for partition from ",start,"to ",mid 
		t1.start()
		#print t2.getName(),"is running for ",str(arr)
		#print t2.getName(),"is running for partition from ",mid+1,"to ",last
		t2.start()
		t1.join()
		t2.join()

class Test(unittest.TestCase):
	def test_postive(self):
		for i in range(0,10000):
			continue
		self.assertEquals(takeInput("input.xml"),[17,1,3,66,81,69,25,15,93,6])
	def test_negative(self):
		self.assertRaises(IOError,takeInput,"input.txt")

input_file='input.xml'
arr=takeInput(input_file)
for i in range(0,10000):
	continue
quickSort(arr,0,len(arr)-1)
print ("Sorted Array:"+ str(arr))
print ("Testing Results...\n")
for i in range(0,100000):
	continue
unittest.main()
