import threading
import random
import time
from pymongo import MongoClient
 
class Philosopher(threading.Thread):
    running = True
    connection = MongoClient("127.0.0.1",27017)
    #URI="mongodb://user:pass@ip:port/dbname"
    #connection=MongoClient(URI)
    @staticmethod
    def sendToMongo(index):
        db = Philosopher.connection.test.dini
        post={"time":time.ctime(),"philo":index}
        db.insert(post)
 
    def __init__(self, i, xname, forkOnLeft, forkOnRight):
        threading.Thread.__init__(self)
        self.name = xname
        self.index=i
        self.forkOnLeft = forkOnLeft
        self.forkOnRight = forkOnRight
 
    def run(self):
        while(self.running):
            time.sleep( random.uniform(3,13))
            print '%s is hungry.' % self.name
            self.dine()
 
    def dine(self):
        fork1, fork2 = self.forkOnLeft, self.forkOnRight
 
        while self.running:
            fork1.acquire(True)
            locked = fork2.acquire(False)
            if locked: break
            fork1.release()
            print '%s swaps forks' % self.name
            fork1, fork2 = fork2, fork1
        else:
            return
 
        self.dining()
        fork2.release()
        fork1.release()
 
    def dining(self):			
        print '%s starts eating '% self.name
        Philosopher.sendToMongo(self.index)
        time.sleep(random.uniform(1,10))
        print '%s finishes eating and leaves to think.' % self.name
        
def DiningPhilosophers():
    forks = [threading.Lock() for n in range(5)]
    philosopherNames = ('Aristotle','Kant','Buddha','Marx', 'Russel')
 
    philosophers= [Philosopher(i, philosopherNames[i], forks[i%5], forks[(i+1)%5]) \
            for i in range(5)]
 
    random.seed(507129)
    Philosopher.running = True
    for p in philosophers: p.start()
    time.sleep(100)
    Philosopher.running = False
    print ("Now we're finishing.")

DiningPhilosophers()

'''OUTPUT
[akmyths@localhost A4]$ python A4.py 
Russel is hungry.
Russel starts eating 
Aristotle is hungry.
Marx is hungry.
Marx swaps forks
Kant is hungry.
Kant starts eating 
Buddha is hungry.
Russel finishes eating and leaves to think.
Aristotle swaps forks
Marx starts eating 
Kant finishes eating and leaves to think.
Buddha swaps forks
Aristotle starts eating 
Aristotle finishes eating and leaves to think.
Marx finishes eating and leaves to think.
Buddha starts eating 
Russel is hungry.
Russel starts eating 
Kant is hungry.
Kant swaps forks
Aristotle is hungry.
Russel finishes eating and leaves to think.
Aristotle starts eating 
Marx is hungry.
Buddha finishes eating and leaves to think.
Kant swaps forks
Marx starts eating 
Russel is hungry.
Marx finishes eating and leaves to think.
Russel swaps forks
Aristotle finishes eating and leaves to think.
Russel starts eating 
 Kant starts eating 
Russel finishes eating and leaves to think.
Kant finishes eating and leaves to think.
Buddha is hungry.
Buddha starts eating 
Marx is hungry.
Kant is hungry.
Kant swaps forks
Aristotle is hungry.
Aristotle starts eating 
Buddha finishes eating and leaves to think.
Marx starts eating 
Kant swaps forks
Marx finishes eating and leaves to think.
Russel is hungry.
Russel swaps forks
Buddha is hungry.
Buddha starts eating 
Marx is hungry.
Aristotle finishes eating and leaves to think.
Kant swaps forks
Russel starts eating 
Buddha finishes eating and leaves to think.
Kant starts eating 
Marx swaps forks
Aristotle is hungry.
Russel finishes eating and leaves to think.
Marx starts eating 
 Aristotle swaps forks
Buddha is hungry.
Kant finishes eating and leaves to think.
Buddha swaps forks
Aristotle starts eating 
Aristotle finishes eating and leaves to think.
Marx finishes eating and leaves to think.
Buddha starts eating 
Aristotle is hungry.
Aristotle starts eating 
Russel is hungry.
Russel swaps forks
Kant is hungry.
Marx is hungry.
Buddha finishes eating and leaves to think.
Marx starts eating 
Aristotle finishes eating and leaves to think.
Russel swaps forks
 Kant starts eating 
Kant finishes eating and leaves to think.
Marx finishes eating and leaves to think.
Russel starts eating 
Aristotle is hungry.
Kant is hungry.
Kant starts eating 
Russel finishes eating and leaves to think.
Aristotle swaps forks
Buddha is hungry.
Russel is hungry.
Russel starts eating 
Marx is hungry.
Marx swaps forks
Kant finishes eating and leaves to think.
Aristotle swaps forks
Buddha starts eating 
Russel finishes eating and leaves to think.
Marx swaps forks
Aristotle starts eating 
Buddha finishes eating and leaves to think.
Marx starts eating 
Aristotle finishes eating and leaves to think.
Now we're finishing.
Kant is hungry.
Marx finishes eating and leaves to think.
Aristotle is hungry.
Buddha is hungry.
Russel is hungry.
[akmyths@localhost A4]$ 

DB output

[cnlab@sammyak ~]$ mongo
MongoDB shell version: 2.4.6
connecting to: test
> use test
switched to db test
> show collections
dini
system.indexes
> 
> show dini
Wed Mar 14 10:09:40.319 don't know how to show [dini] at src/mongo/shell/utils.js:847
> db.dini.find()
{ "_id" : ObjectId("5aa8a45b1b7be214aced7fbb"), "philo" : 4, "time" : "Wed Mar 14 09:56:03 2018" }
{ "_id" : ObjectId("5aa8a4601b7be214aced7fbc"), "philo" : 1, "time" : "Wed Mar 14 09:56:08 2018" }
{ "_id" : ObjectId("5aa8a4641b7be214aced7fbd"), "philo" : 3, "time" : "Wed Mar 14 09:56:12 2018" }
{ "_id" : ObjectId("5aa8a4661b7be214aced7fbe"), "philo" : 0, "time" : "Wed Mar 14 09:56:14 2018" }
{ "_id" : ObjectId("5aa8a4661b7be214aced7fbf"), "philo" : 2, "time" : "Wed Mar 14 09:56:14 2018" }
{ "_id" : ObjectId("5aa8a46c1b7be214aced7fc0"), "philo" : 4, "time" : "Wed Mar 14 09:56:20 2018" }
{ "_id" : ObjectId("5aa8a46f1b7be214aced7fc1"), "philo" : 3, "time" : "Wed Mar 14 09:56:23 2018" }
{ "_id" : ObjectId("5aa8a4701b7be214aced7fc2"), "philo" : 0, "time" : "Wed Mar 14 09:56:24 2018" }
{ "_id" : ObjectId("5aa8a4751b7be214aced7fc3"), "philo" : 2, "time" : "Wed Mar 14 09:56:29 2018" }
{ "_id" : ObjectId("5aa8a47a1b7be214aced7fc4"), "philo" : 1, "time" : "Wed Mar 14 09:56:34 2018" }
{ "_id" : ObjectId("5aa8a47a1b7be214aced7fc5"), "philo" : 4, "time" : "Wed Mar 14 09:56:34 2018" }
{ "_id" : ObjectId("5aa8a4821b7be214aced7fc6"), "philo" : 2, "time" : "Wed Mar 14 09:56:42 2018" }
{ "_id" : ObjectId("5aa8a4831b7be214aced7fc7"), "philo" : 0, "time" : "Wed Mar 14 09:56:43 2018" }
{ "_id" : ObjectId("5aa8a4871b7be214aced7fc8"), "philo" : 3, "time" : "Wed Mar 14 09:56:47 2018" }
{ "_id" : ObjectId("5aa8a48a1b7be214aced7fc9"), "philo" : 4, "time" : "Wed Mar 14 09:56:50 2018" }
{ "_id" : ObjectId("5aa8a48c1b7be214aced7fca"), "philo" : 1, "time" : "Wed Mar 14 09:56:52 2018" }
{ "_id" : ObjectId("5aa8a4901b7be214aced7fcb"), "philo" : 2, "time" : "Wed Mar 14 09:56:56 2018" }
{ "_id" : ObjectId("5aa8a4931b7be214aced7fcc"), "philo" : 0, "time" : "Wed Mar 14 09:56:59 2018" }
{ "_id" : ObjectId("5aa8a4951b7be214aced7fcd"), "philo" : 3, "time" : "Wed Mar 14 09:57:01 2018" }
{ "_id" : ObjectId("5aa8a4991b7be214aced7fce"), "philo" : 2, "time" : "Wed Mar 14 09:57:05 2018" }
Type "it" for more
> 

'''
