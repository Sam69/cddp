package com.example.omkar.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button add,sub,mul,div,sqrt,sin;
    private TextView t1;
    private EditText e1,e2;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    public void init() {
        add=(Button) findViewById(R.id.add);
        sub=(Button) findViewById( R.id.subt);
        mul=(Button) findViewById(R.id.mul);
        div=(Button) findViewById(R.id.div);
        sin=(Button) findViewById(R.id.sin);

        e1=(EditText) findViewById(R.id.e1);
        e2=(EditText) findViewById(R.id.e2);

        t1= (TextView) findViewById(R.id.res);

        add.setOnClickListener(this);
        sub.setOnClickListener(this);
        mul.setOnClickListener(this);
        div.setOnClickListener(this);
        sin.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        String num1=e1.getText().toString();
        String num2=e2.getText().toString();

        Double res, saved_value=0.0;
        switch (v.getId()){
            case R.id.add:
                /*res=Double.parseDouble(num1)+Double.parseDouble(num2);
                t1.setText(String.valueOf(res));
                break;*/
                String value = e1.getText().toString();
                saved_value = Double.parseDouble(value);
                //e1.setText(" ");
                e2.setText(" ");
                t1.setText(String.valueOf("Result"));
                break;
            case R.id.subt:
                /*res=Double.parseDouble(num1)-Double.parseDouble(num2);
                t1.setText(String.valueOf(res));
                break;*/
                t1.setText(String.valueOf(saved_value));
                break;
            case R.id.mul:
                res=Double.parseDouble(num1)*Double.parseDouble(num2);
                t1.setText(String.valueOf(res));
                break;
            case R.id.div:
                res=Double.parseDouble(num1)/Double.parseDouble(num2);
                t1.setText(String.valueOf(res));
                break;
            case R.id.sin:
                res=Math.sin(Double.parseDouble(num1));
                t1.setText(String.valueOf(res));
            case R.id.fileread:
                try {
                    Context context=this;
                    AssetManager am =context.getAssets();
                    InputStream is = am.open("file.txt");
                    BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                    String n1=buf.readLine();
                    String n2=buf.readLine();
                    num1.setText(n1);
                    num2.setText(n2);

                } catch(Exception e)
                {
                    e.printStackTrace();
                }
                break;

        }

    }
}
