import socket
import sys

def chunks(l,n):
	return [l[i:i+n] for i in range(0, len(l), n)]

def rol(n,b):
	return ((n<<b)|(n>>(32-b))) & 0xffffffff

def sha1(data):
	bytes=""
	h0=0x67452310
	h1=0xEFCDAB89
	h2=0x98BADCFE
	h3=0x01325476
	h4=0xC3D2E1F0

	for n in range (len(data)):
		bytes+='{0:08b}'.format(ord(data[n]))
	bytes+="1"
	pBits=bytes
	
	while (len(pBits)%512!=448):
		pBits+="0"
	#print "Length of bytes:\n"
	#print len(bytes)

	pBits+='{0:064b}'.format(len(bytes)-1)
	#print(pBits)

	for ch in chunks(pBits,512):
		words=chunks(ch,32)
		print(words)
		w=[0]*80
		for i in range(0,16):
			w[i]=int(words[i],2)
			print w[i]
		for i in range(16,80):
			w[i]=rol((w[i-3]^w[i-8]^w[i-14]^w[i-16]),1)


		a=h0
		b=h1
		c=h2
		d=h3
		e=h4
		
		for i in range (0,80):
			if 0<=i<=19:
				f=(b&c)|((~b)&d)
				k=0x01234567
			elif 20<=i<=39:
				f=b^c^d
				k=0x89ABCDEF
			elif 40<=i<=59:
				f=(b&c)|(c&d)|(b&d)
				k=0x02468ACE
			elif 60<=i<=79:
				f=b^c^d
				k=0x13579BDF
			temp=rol(a,5)+f+k+e+w[i]&0xffffffff
			print "temp"

			print temp
			e=d
			d=c
			c=rol(b,30)
			b=a
			a=temp
		
		h0+=a&0xffffffff
		h1+=b&0xffffffff
		h2+=c&0xffffffff
		h3+=d&0xffffffff
		h4+=e&0xffffffff

	return "%08x%08x%08x%08x%08x" %(h0,h1,h2,h3,h4)

if __name__=='__main__':
	message = str(raw_input())
	sha1(message)

	s=socket.socket()
	s.bind(('127.0.0.1',6000))

	s.listen(5)
	conn,cli=s.accept()

	msg=conn.recv(1024)
	digs=conn.recv(1024)
	ver=sha1(msg)
	print msg
	if(digs==ver):
		print "Success!"
	else:
		print "Failure"
